Note: *.tra-Files starting with "wrong_format" are to produce an error when 
being parsed. Hence, spelling errors and wrong formats are on purpose.
DO NOT CORRECT THEM!  